# for linux

Run the script 
./<script name>
