# Only for MACOS

Run the script 
./<script name>

Links to use:
Color coding - https://www.cyberciti.biz/tips/freebsd-how-to-enable-colorized-ls-output.html
Making BSDcolour code - https://geoff.greer.fm/lscolors/
